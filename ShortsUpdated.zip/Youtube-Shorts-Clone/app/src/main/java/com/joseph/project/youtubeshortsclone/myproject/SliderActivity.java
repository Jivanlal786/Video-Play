package com.joseph.project.youtubeshortsclone.myproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.joseph.project.youtubeshortsclone.R;
import com.joseph.project.youtubeshortsclone.myproject.myadapters.MyVideoScrollerAdapter;

import java.util.ArrayList;

public class SliderActivity extends AppCompatActivity {

    ViewPager2 videoScroller;
    ProgressBar videoScrollProgressBar;
    MyVideoScrollerAdapter adapter;
    ArrayList<String> videoList = new ArrayList<>();
    int page = 0;
    private String TAG = "JJJJJJJJ_";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slider);

        videoScroller = findViewById(R.id.videoScroller);
        videoScrollProgressBar = findViewById(R.id.videoScrollProgressBar);

        videoScrollProgressBar.setVisibility(View.GONE);
        fetchVideo(page);

        adapter = new MyVideoScrollerAdapter(videoList, this);
        videoScroller.setAdapter(adapter);


        videoScroller.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);

                Log.e(TAG, "onPageSelected: " + position);
                if (videoScroller.getCurrentItem() == (videoList.size() - 1)) {
                    page++;
                    if (page > 2) {
                        page = 0;
                    }
                    Log.e(TAG, "onPageScrollStateChanged: page==> " + page);
                    videoScrollProgressBar.setVisibility(View.VISIBLE);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            fetchVideo(page);
                            videoScrollProgressBar.setVisibility(View.GONE);
                        }
                    }, 3000);

                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);

                /*if (state == ViewPager2.SCROLL_STATE_IDLE || state == ViewPager2.SCROLL_STATE_DRAGGING) {
                    if (videoScroller.getCurrentItem() == (videoList.size() - 1)) {
                        page++;
                        Log.e(TAG, "onPageScrollStateChanged: page==> "+page);
                        videoScrollProgressBar.setVisibility(View.VISIBLE);
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                fetchVideo(page);
                                videoScrollProgressBar.setVisibility(View.GONE);
                            }
                        },3000);

                    }
                }*/
            }
        });


    }

    @Override
    protected void onPause() {
        super.onPause();
        if (adapter != null) {
            adapter.pauseVideo();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.resumeVideo();
        }
    }

    private void fetchVideo(int page) {
        if (videoList == null) {
            videoList = new ArrayList<>();
        }
        if (page == 0) {
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/609353d5037a72c3_image348823.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/75372bb5917a5961_image793581.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/e8ef34a12dd88968_image91678.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/bc45d33283ba604e_VID-20231015-WA0005.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/image/22d43cd43338317c_image355887.jpg");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/7319860620cd6ae5_FB_VID_9027641155387231479.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/e543c23406b78e9a_VID-20231015-WA0021.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/a9b3b457fc8866d1_image507247.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/image/f9f9594da2bc338d_IMG_20230922_094225_647.jpg");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/1cbcf4a1d352378e_Screenrecording_20230928_094827.mp4");
        }
        if (page == 1) {
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/b7bc0aa30501c141_image789415.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/16218896768f653a_065502525.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/5659232cb10374f4_125244105.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/9d8ea91847fbaba1_image320623.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/b7222455a2a0b33d_image888878.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/f843f70d85a27d96_image648634.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/d6ef8b3a0bd6d52e_4.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/2bbb2cda30e4b477_बिना शीर्षक के 11_1080p_5.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/a843570f3362a8d9_image58793.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/f357da6a935e1214_image120864.mp4");
        }

        if (page == 2) {
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/54835386e2dea2d0_image323669.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/6032f9f57dba730d_image163419.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/24654ab1ad798eb2_image875092.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/d39bcddd39f4b397_image528954.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/a6ca5cedf858318f_Snapchat-161831950.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/cef05f5e7ce97f76_image348483.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/8778509fb2ba2966_image922028.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/65588d267092b919_image794499.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/c99d0a0c51ad56a1_image459458.mp4");
            videoList.add("https://1752375227.rsc.cdn77.org/Data/video/58109c75ee09aa29_image741407.mp4");
            page = -1;
        }
    }
}