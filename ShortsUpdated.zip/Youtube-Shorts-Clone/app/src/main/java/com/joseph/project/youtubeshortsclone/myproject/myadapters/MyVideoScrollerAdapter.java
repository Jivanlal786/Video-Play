package com.joseph.project.youtubeshortsclone.myproject.myadapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSourceFactory;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SimpleExoPlayer;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.RecyclerView;

import com.joseph.project.youtubeshortsclone.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Objects;

@SuppressLint("UnsafeOptInUsageError")
public class MyVideoScrollerAdapter extends RecyclerView.Adapter<MyVideoScrollerAdapter.VideoScrollViewHolder> {
    private ArrayList<String> vList;
    private Context context;
    private ExoPlayer player;
    private SimpleCache simpleCache;
    private String TAG = "JJJJJJJJ";


    public MyVideoScrollerAdapter(ArrayList<String> vList, Context context) {
        this.vList = vList;
        this.context = context;

        LeastRecentlyUsedCacheEvictor evictor = new LeastRecentlyUsedCacheEvictor(100 * 1024 * 1024);
        File cacheDir = new File(context.getCacheDir(), "media");
        simpleCache = new SimpleCache(cacheDir, evictor);
    }

    @NonNull
    @Override
    public VideoScrollViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View videoScroller = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_item, parent, false);
        return new VideoScrollViewHolder(videoScroller);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoScrollViewHolder holder, int position) {
        String videoElement = vList.get(position);
/*        String handleText = "@" + videoElement.getCreator().getHandle();
       holder.handle.setText(handleText);
        holder.title.setText(videoElement.getSubmission().getTitle());
        holder.description.setText(videoElement.getSubmission().getDescription());
        holder.comments.setText(String.valueOf(videoElement.getComment().getCount()));
        holder.reaction.setText(String.valueOf(videoElement.getReaction().getCount()));*/

        Log.e(TAG, "onBindViewHolder: vList.size() ==> "+vList.size());

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(context);
        trackSelector.setParameters(trackSelector.buildUponParameters().setMaxVideoSizeSd());
        player = new ExoPlayer.Builder(context).setTrackSelector(trackSelector).build();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
//                Player.Listener.super.onPlayerError(error);
                Log.e(TAG, "onPlayerError: "+error.getMessage());
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
//                Player.Listener.super.onPlaybackStateChanged(playbackState);

                if (playbackState == Player.STATE_ENDED) {
                    // Video playback completed
                    // Do something when the video is completed
                    Log.d("VideoScrollerAdapter", "Video Playback Completed");
                }
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                Player.Listener.super.onIsPlayingChanged(isPlaying);
                if (isPlaying) {
                    // Video started playing
                    Log.d("VideoScrollerAdapter", "Video Started Playing");
                    // Track video playback progress
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            long currentPosition = player.getCurrentPosition();
                            long duration = player.getDuration();
                            float progress = (float) currentPosition / duration;
                            Log.d("VideoScrollerAdapter", "Video Playback Progress: " + progress);
                            handler.postDelayed(this, 1000); // Log progress every second
                        }
                    }, 1000); // Start logging progress after 1 second
                } else {
                    // Video paused or stopped
                    Log.d("VideoScrollerAdapter", "Video Paused or Stopped");
                }
            }


        });

//        player.addListener(object : Player.Listener {
//            override fun onPlayerError(error: PlaybackException) {
//                super.onPlayerError(error)
//                Toast.makeText(context, "Can't play this video", Toast.LENGTH_SHORT).show()
//            }
//
//            override fun onPlayerStateChanged(playWhenReady: Boolean, playbackState: Int) {
//                if (playbackState == Player.STATE_BUFFERING) {
//                    binding.pbLoading.visibility = View.VISIBLE
//                } else if (playbackState == Player.STATE_READY) {
//                    binding.pbLoading.visibility = View.GONE
//                }
//            }
//        })

        holder.videoFrame.setPlayer(player);
        MediaItem mediaItem = MediaItem.fromUri(Uri.parse(videoElement));
        DefaultHttpDataSource.Factory httpDataSourceFactory = new DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true);
        DefaultDataSourceFactory defaultDataSourceFactory = new DefaultDataSourceFactory(context, httpDataSourceFactory);
        CacheDataSource.Factory cacheDataSourceFactory = new CacheDataSource.Factory()
                .setCache(simpleCache)
                .setUpstreamDataSourceFactory(defaultDataSourceFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

        ProgressiveMediaSource mediaSource = new ProgressiveMediaSource.Factory(cacheDataSourceFactory).createMediaSource(mediaItem);
        player.setMediaSource(mediaSource);
        player.setPlayWhenReady(false);
        player.setRepeatMode(ExoPlayer.REPEAT_MODE_ONE);
        player.prepare();

      /*  player.addListener(new ExoPlayer.EventListener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == ExoPlayer.STATE_ENDED) {
                    // Video playback completed
                    // Do something when the video is completed
                    Log.d("VideoScrollerAdapter", "Video Playback Completed");
                }
            }

            @Override
            public void onPlayWhenReadyChanged(boolean playWhenReady, int playbackState) {
                if (playWhenReady && playbackState == ExoPlayer.STATE_READY) {
                    // Video started playing
                    Log.d("VideoScrollerAdapter", "Video Started Playing");
                    // Track video playback progress
                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            long currentPosition = player.getCurrentPosition();
                            long duration = player.getDuration();
                            float progress = (float) currentPosition / duration;
                            Log.d("VideoScrollerAdapter", "Video Playback Progress: " + progress);
                            handler.postDelayed(this, 1000); // Log progress every second
                        }
                    }, 1000); // Start logging progress after 1 second
                } else {
                    // Video paused or stopped
                    Log.d("VideoScrollerAdapter", "Video Paused or Stopped");
                }
            }

            // ... (other ExoPlayer.EventListener methods)
        });*/
    }

    public void pauseVideo() {
        if (player != null && player.isPlaying()) {
//            player.setPlayWhenReady(false);
            player.pause();

        }
    }

    public void resumeVideo() {
        if (player != null && !player.isPlaying()) {
//            player.setPlayWhenReady(true);
            player.play();

        }
    }

    @Override
    public void onViewAttachedToWindow(@NonNull VideoScrollViewHolder holder) {
        super.onViewAttachedToWindow(holder);

        Objects.requireNonNull(holder.videoFrame.getPlayer()).seekTo(0);
        holder.videoFrame.getPlayer().setPlayWhenReady(true);
        if (holder.videoFrame.getPlayer().getPlayerError() != null) {
            holder.videoFrame.getPlayer().prepare();
        }
    }

    @Override
    public void onDetachedFromRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);

        Log.d("VideoScrollerAdapter", "Player Released onDetach");
        player.release();
        simpleCache.release();

    }

    @Override
    public void onViewRecycled(@NonNull VideoScrollViewHolder holder) {
        super.onViewRecycled(holder);

        Log.d("VideoScrollerAdapter", "View recycled");
        Objects.requireNonNull(holder.videoFrame.getPlayer()).release();
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull VideoScrollViewHolder holder) {
        super.onViewDetachedFromWindow(holder);

        Objects.requireNonNull(holder.videoFrame.getPlayer()).pause();
    }

    @Override
    public int getItemCount() {
        return vList.size();
    }

    static class VideoScrollViewHolder extends RecyclerView.ViewHolder {
        TextView handle, title, description, comments, reaction;
        PlayerView videoFrame;

        VideoScrollViewHolder(@NonNull View itemView) {
            super(itemView);
            handle = itemView.findViewById(R.id.handleText);
            title = itemView.findViewById(R.id.videoTitleText);
            description = itemView.findViewById(R.id.videoDescriptionText);
            comments = itemView.findViewById(R.id.commentCount);
            reaction = itemView.findViewById(R.id.reactionCount);
            videoFrame = itemView.findViewById(R.id.videoFrame);
        }
    }
}
