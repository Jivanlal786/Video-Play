package com.example.viewpager2withexoplayer

import com.google.android.exoplayer2.ExoPlayer

class ExoPlayerItem(
    var exoPlayer: ExoPlayer,
    var position: Int
)