package com.example.viewpager2withexoplayer

class Video(
    var title: String,
    var url: String
)