package com.joseph.project.youtubeshortsclone.model

data class Comment(
    val commentingAllowed: Boolean,
    val count: Int
)