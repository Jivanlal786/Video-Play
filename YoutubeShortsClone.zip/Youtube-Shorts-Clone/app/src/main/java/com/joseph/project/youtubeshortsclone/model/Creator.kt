package com.joseph.project.youtubeshortsclone.model

data class Creator(
    val handle: String,
    val id: String,
    val name: String,
    val pic: String
)