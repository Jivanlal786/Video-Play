package com.joseph.project.youtubeshortsclone.model

data class Reaction(
    val count: Int,
    val voted: Boolean
)