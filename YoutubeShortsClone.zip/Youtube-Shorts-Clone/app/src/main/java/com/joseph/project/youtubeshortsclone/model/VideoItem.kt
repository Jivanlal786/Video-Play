package com.joseph.project.youtubeshortsclone.model

data class VideoItem(
    val `data`: Data,
    val message: String
)